m = float(input()) # Accepting input as float to check for non-integer values
n = int(m) # Converting to integer
if n!=m or n < 1 or n > 9: # Checking if input is not an integer or out of range
    print("Invalid")
else:
    for i in range(1, n + 1):
        row = "" # Initialize an empty string for each row
        for j in range(1, i + 1):
            row += f"{j}x{i}={i*j:2}" + "\t" # Formatting each multiplication expression
        print(row)