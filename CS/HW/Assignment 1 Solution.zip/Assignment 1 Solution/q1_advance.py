m = input() # Accepting input
if not m.isdigit() or int(m) < 1 or int(m) > 9:  # Checking if input is not an integer or out of range
    print("Invalid")
else:
    for i in range(1, int(m) + 1):
        row = "\t".join(f"{j}x{i}={i*j:2}" for j in range(1, i + 1)) # Formatting each multiplication expression
        print(row)