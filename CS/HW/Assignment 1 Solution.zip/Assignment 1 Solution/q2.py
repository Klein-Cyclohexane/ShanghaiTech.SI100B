# Read input values
x1 = float(input())
y1 = float(input())
x2 = float(input())
y2 = float(input())
x = float(input())

# Apply linear interpolation formula
# y = y1 + (y2 - y1) / (x2 - x1) * (x - x1)
y = y1 + (y2 - y1) / (x2 - x1) * (x - x1)

# Output with 2 decimal places
print(f"{y:.2f}")
