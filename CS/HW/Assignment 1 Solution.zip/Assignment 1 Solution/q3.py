h = int(input())  # height (odd number)
w = int(input())  # width difference between rows (even number)
c = input()       # character to use

# Calculate middle row index
middle = h // 2

# Calculate the maximum number of characters (in the middle row)
max_chars = 1 + middle * w

# Generate upper half (including middle)
for i in range(middle + 1):
    # Number of characters in this row
    num_chars = 1 + i * w
    
    # Number of spaces before characters (centered based on max width)
    num_spaces = (max_chars - num_chars) // 2
    
    # Print spaces + characters
    print(" " * num_spaces + c * num_chars)

# Generate lower half
for i in range(middle - 1, -1, -1):
    # Number of characters in this row
    num_chars = 1 + i * w
    
    # Number of spaces before characters (centered based on max width)
    num_spaces = (max_chars - num_chars) // 2
    
    # Print spaces + characters
    print(" " * num_spaces + c * num_chars)
