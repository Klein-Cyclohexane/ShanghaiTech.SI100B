a = float(input()) # Input a positive floating-point number
guess = a / 2 # Initial guess
for _ in range(20): # We conventionally employ the underscore (_) to denote variables that will remain unused in subsequent operations.
    guess = (guess + a / guess) / 2 # Update guess using the Babylonian method
print("{0:.20f}".format(guess)) # Print the result with 20 decimal places
