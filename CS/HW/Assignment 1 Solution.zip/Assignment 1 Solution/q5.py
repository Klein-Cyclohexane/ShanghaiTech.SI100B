s = input() # Read input string
n = len(s) # Length of the string
cnt = 0 # Initialize palindrome count

# Odd-length palindromes: single-character center
for c in range(n): # Center index
    l = r = c # Left and right pointers
    while l >= 0 and r < n and s[l] == s[r]: # Expand while characters match
        cnt += 1 # Count the palindrome
        l -= 1 # Move left pointer outward 
        r += 1 # Move right pointer outward

# Even-length palindromes: gap between two adjacent characters as center
for c in range(n - 1): # Center gap index
    l, r = c, c + 1 # Left and right pointers
    while l >= 0 and r < n and s[l] == s[r]: # Expand while characters match
        cnt += 1 # Count the palindrome
        l -= 1 # Move left pointer outward 
        r += 1 # Move right pointer outward

print(cnt) # Print the total count of palindromic substrings