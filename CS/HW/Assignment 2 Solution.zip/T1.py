from typing import Callable, Dict

Number = int | float
BinaryOp = Callable[[Number, Number], Number]

op_dict: Dict[str, BinaryOp] = {
    "add": lambda x, y: x + y,
    "sub": lambda x, y: x - y,
    "mul": lambda x, y: x * y,
    "div": lambda x, y: x / y,
    "pow": lambda x, y: x ** y,
    "max": lambda x, y: x if x > y else y,
    "min": lambda x, y: x if x < y else y,
}


def get_op(name: str) -> BinaryOp:
    return op_dict[name]


def calc(op: BinaryOp, x: Number, y: Number) -> float:
    return op(x, y)


print(get_op('add')(2, 3))
