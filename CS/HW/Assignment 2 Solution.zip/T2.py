from math import floor
from typing import List

n = int(input())
pixels = list(map(int, input().split()))
a, b = map(float, input().split())
low, high = map(int, input().split())

result: List[int] = []
for x in pixels:
    # Linear transform
    y = a * x + b
    # Quantization
    y_q = floor(y + 0.5)
    # Clipping
    y_out = min(max(y_q, low), high)
    result.append(y_out)

print(' '.join(map(str, result)))
