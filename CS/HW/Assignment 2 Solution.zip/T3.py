from typing import List

n, m = map(int, input().split())
grid: List[List[str]] = [input().split() for _ in range(n)]
score: int = 0


def get_grid(x: int, y: int) -> str:
    return grid[x-1][y-1]


def swap_grid(x1: int, y1: int, x2: int, y2: int) -> None:
    grid[x1-1][y1-1], grid[x2-1][y2-1] = grid[x2-1][y2-1], grid[x1-1][y1-1]


def print_grid() -> None:
    for line in grid:
        print(' '.join(line))


# Check whether the grid cell (x, y) is within valid boundaries.
def is_block_vaild(x: int, y: int) -> bool:
    return x >= 1 and x <= n and y >= 1 and y <= m


# Attempt to swap two cells and remove matching vertical or horizontal blocks.
# Return the number of matches removed.
def do_swap(x1: int, y1: int, x2: int, y2: int) -> int:
    if get_grid(x1, y1) == '.' or get_grid(x2, y2) == '.':
        return 0
    # Check swap in row direction
    if x1 == x2 and abs(y1 - y2) == 1:
        if x1 == 1 or x1 == n:
            return 0
        cnt = 0
        # Try to swap first
        swap_grid(x1, y1, x2, y2)
        # Check if y1 column can be mathced
        if get_grid(x1-1, y1) == get_grid(x1, y1) == get_grid(x1+1, y1):
            cnt += 1
            grid[x1-2][y1-1] = '.'
            grid[x1-1][y1-1] = '.'
            grid[x1][y1-1] = '.'
        # Check if y2 column can be mathced
        if get_grid(x1-1, y2) == get_grid(x1, y2) == get_grid(x1+1, y2):
            cnt += 1
            grid[x1-2][y2-1] = '.'
            grid[x1-1][y2-1] = '.'
            grid[x1][y2-1] = '.'
        # If invaild, recover
        if cnt == 0:
            swap_grid(x1, y1, x2, y2)
        return cnt
    # Check swap in column direction
    elif abs(x1 - x2) == 1 and y1 == y2:
        if y1 == 1 or y1 == m:
            return 0
        cnt = 0
        # Try to swap first
        swap_grid(x1, y1, x2, y2)
        # Check if x1 row can be mathced
        if get_grid(x1, y1-1) == get_grid(x1, y1) == get_grid(x1, y1+1):
            cnt += 1
            grid[x1-1][y1-2] = '.'
            grid[x1-1][y1-1] = '.'
            grid[x1-1][y1] = '.'
        # Check if x2 row can be mathced
        if get_grid(x2, y1-1) == get_grid(x2, y1) == get_grid(x2, y1+1):
            cnt += 1
            grid[x2-1][y1-2] = '.'
            grid[x2-1][y1-1] = '.'
            grid[x2-1][y1] = '.'
        # If invaild, recover
        if cnt == 0:
            swap_grid(x1, y1, x2, y2)
        return cnt

    else:
        return 0


print_grid()
print(score)

while True:
    cmd = input().split()
    if not cmd:
        continue

    if cmd[0] == "swap":
        x1, y1, x2, y2 = map(int, cmd[1:])
        if is_block_vaild(x1, y1) and is_block_vaild(x2, y2):
            cnt = do_swap(x1, y1, x2, y2)
            score += cnt * 30
        print_grid()
        print(score)

    elif cmd[0] == "exit":
        print(score)
        break
