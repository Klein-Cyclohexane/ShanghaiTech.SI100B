from typing import List, Optional
data_list = List[float | int | bool]

L = int(input())
data: data_list = []
for _ in range(L):
    # item[i] = [lap_number, s1_time, s2_time, s3_time, pit_stop_time,
    #            lap_time, total_time, is_s1_green, is_s2_green, is_s3_green]
    s = input().split(',')
    item = [int(s[0]), float(s[1]), float(s[2]), float(s[3]), float(s[4])]
    item.append(item[1] + item[2] + item[3])
    item.append(item[5] + item[4])
    item += [False] * 3
    data.append(item)
original_data: data_list = data[:]

# Pre-Process
best_lap = 0
pit_laps: List[int] = []
best_sector: List[float] = [0.0] * 3
for i, item in enumerate(data):
    if item[4] > 0.0:
        pit_laps.append(i)
    if i == 0:
        for j in range(3):
            best_sector[j] = item[j+1]  # item[f"s{i+1}_time"]
            item[j+7] = True            # item[f"is_s{i+1}_green"]
    else:
        if item[5] < data[best_lap][5]:
            best_lap = i
        for j in range(3):
            item[j+7] = (best_sector[j] > item[j+1])
            if item[j+7]:
                best_sector[j] = item[j+1]


# Commands Function


# Returns the lap number with the fastest lap time. (If tied, return the smallest lap number.)
def get_best_lap() -> int:
    return best_lap


# Returns a list of all lap numbers where a pit stop occurred. (ascending order)
def get_pit_laps() -> List[int]:
    return pit_laps


# Returns the lap time with lap number i.
def get_lap_time(i: int) -> float:
    return original_data[i][5]


# Returns the all-time personal best time for Sector s.
def get_best_sector(s: int) -> float:
    return best_sector[s-1]


# Returns a list of lap numbers where a pit stop occurred with time ≤ t (ascending order).
def get_pit_time_less_than(t: float) -> List[int]:
    res: List[int] = []
    for item in data:
        if 0.0 < item[4] <= t:          # item["pit_stop_time"]
            res.append(item[0])
    return sorted(res)


# Returns the average lap time of laps within the slice [start:end:step].
def get_avg_lap(start: int, end: int, step: int) -> Optional[float]:
    data_slice = data[start:end:step]
    if not data_slice:
        return None
    res = 0.0
    for item in data_slice:
        res += item[5]                  # item["lap_time"]
    return res / len(data_slice)


# Returns the sum of total time for laps in the slice.
def get_stint_time(start: int, end: int, step: int) -> Optional[float]:
    data_slice = data[start:end:step]
    if not data_slice:
        return None
    res = 0.0
    for item in data_slice:
        res += item[6]                  # item["total_time"]
    return res


# Returns the list of lap numbers where Sector s was green within the slice (ascending order).
def get_green_laps(s: int, start: int, end: int, step: int) -> Optional[List[int]]:
    data_slice = data[start:end:step]
    if not data_slice:
        return None
    res: List[int] = []
    for item in data_slice:
        if item[s+6]:                   # item[f"is_s{s}_green"]
            res.append(item[0])         # item["total_time"]
    return sorted(res)


# Returns the pit-stop rate = (number of pit-stop laps) ÷ (slice length).
def get_pit_rate(start: int, end: int, step: int) -> Optional[float]:
    data_slice = data[start:end:step]
    if not data_slice:
        return None
    cnt = 0
    for item in data_slice:
        if item[4] > 0.0:               # item["pit_stop_time"]
            cnt += 1
    return cnt / len(data_slice)


# Reorders the current lap dataset by key in ascending (ASC) or descending (DESC) order. (Ties resolved by lap number ascending.) This command has no output. Possible keys: lap_time, total_time, s1, s2, s3.
def reorder(key: str, order: str) -> None:
    # item[i] = [lap_number, s1_time, s2_time, s3_time, pit_stop_time,
    #            lap_time, total_time, is_s1_green, is_s2_green, is_s3_green]
    order_mul = -1 if order == "DESC" else 1
    if key == "lap_time":
        data.sort(key=lambda x: (x[5] * order_mul, x[0]))
    elif key == "total_time":
        data.sort(key=lambda x: (x[6] * order_mul, x[0]))
    elif key == "s1":
        data.sort(key=lambda x: (x[1] * order_mul, x[0]))
    elif key == "s2":
        data.sort(key=lambda x: (x[2] * order_mul, x[0]))
    elif key == "s3":
        data.sort(key=lambda x: (x[3] * order_mul, x[0]))


# Query Loop
N = int(input())
for _ in range(N):
    cmd = input().split(',')
    if not cmd:
        continue

    if cmd[0] == "best_lap":
        print(get_best_lap())
    elif cmd[0] == "pit_laps":
        print(get_pit_laps())
    elif cmd[0] == "lap_time":
        print(f"{get_lap_time(int(cmd[1])):.2f}")
    elif cmd[0] == "best_sector":
        print(f"{get_best_sector(int(cmd[1])):.2f}")
    elif cmd[0] == "pit_time":
        print(get_pit_time_less_than(float(cmd[1])))
    elif cmd[0] == "avg_lap":
        res = get_avg_lap(int(cmd[1]), int(cmd[2]), int(cmd[3]))
        if res is None:
            print("Querying on empty list!")
        else:
            print(f"{res:.2f}")
    elif cmd[0] == "stint_time":
        res = get_stint_time(int(cmd[1]), int(cmd[2]), int(cmd[3]))
        if res is None:
            print("Querying on empty list!")
        else:
            print(f"{res:.2f}")
    elif cmd[0] == "green_laps":
        res = get_green_laps(int(cmd[1]), int(cmd[2]),
                             int(cmd[3]), int(cmd[4]))
        if res is None:
            print("Querying on empty list!")
        else:
            print(res)
    elif cmd[0] == "pit_rate":
        res = get_pit_rate(int(cmd[1]), int(cmd[2]), int(cmd[3]))
        if res is None:
            print("Querying on empty list!")
        else:
            print(f"{res:.2f}")
    elif cmd[0] == "reorder":
        reorder(cmd[1], cmd[2])
