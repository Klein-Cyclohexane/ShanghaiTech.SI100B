def flatten_nested_list(nested: list) -> list:
    """
    Flatten a nested list of arbitrary depth into a one-dimensional list.

    Args:
        nested_list (list): A nested list structure that can contain integers, strings, 
                            floats, booleans, or other nested lists

    Returns:
        list: A flattened one-dimensional list whose elements are in the same order 
              as they appear from left to right in the printed original list.
    """

    res = []
    for elem in nested:
        if type(elem) == list:      # or isinstance(x, list)
            res.extend(flatten_nested_list(elem))
        else:
            res.append(elem)
    return res


nested = [1, [2, [3, 4], 5], 6, [7, 8]]
result = flatten_nested_list(nested)
print(result)
