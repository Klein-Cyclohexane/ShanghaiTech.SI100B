def reverse_sublist(lst: list, l: int, r: int, inplace: bool) -> list:
    """
    Reverse the elements in the sublist [l:r] of a list.

    Args:
        lst (list): The input list to be processed.
        l (int): The starting index of the sublist (inclusive).
        r (int): The ending index of the sublist (exclusive).
        inplace (bool): 
            If True, modifies the list in place and returns the same list.  
            If False, returns a new list with the specified sublist reversed.

    Returns:
        list: The list with the specified sublist reversed.

    Raises:
        AssertionError: If l or r is out of range, or if l >= r.
    """
    assert 0 <= l < r <= len(lst), "Invalid sublist"

    new_lst = lst if inplace else lst.copy()
    new_lst[l:r] = new_lst[l:r][::-1]
    return new_lst


def rotate_sublist(lst: list, l: int, r: int, k: int, inplace: bool) -> list:
    """
    Rotate the elements in the sublist [l:r] of a list to the left by k positions.

    Args:
        lst (list): The input list to be processed.
        l (int): The starting index of the sublist (inclusive).
        r (int): The ending index of the sublist (exclusive).
        k (int): The number of positions to rotate left. Can be any integer.
        inplace (bool): 
            If True, modifies the list in place and returns the same list.  
            If False, returns a new list with the specified sublist rotated.

    Returns:
        list: The list with the specified sublist rotated left by k positions.

    Raises:
        AssertionError: If l or r is out of range, or if l >= r.
    """
    assert 0 <= l < r <= len(lst), "Invalid sublist"

    k %= r-l
    new_lst = lst if inplace else lst.copy()
    new_lst[l:r] = new_lst[l+k:r] + new_lst[l:l+k]
    return new_lst


def swap_sublist(lst: list, l1: int, r1: int, l2: int, r2: int, inplace: bool) -> list:
    """
    Swap two sublists [l1:r1] and [l2:r2] of a list.

    Args:
        lst (list): The input list to be processed.
        l1 (int): The starting index of the first sublist (inclusive).
        r1 (int): The ending index of the first sublist (exclusive).
        l2 (int): The starting index of the second sublist (inclusive).
        r2 (int): The ending index of the second sublist (exclusive).
        inplace (bool): 
            If True, modifies the list in place and returns the same list.  
            If False, returns a new list with the specified sublists swapped.

    Returns:
        list: The list with the specified sublists swapped.

    Raises:
        AssertionError: 
            If the sublist indices are out of range,  
            if l1 >= r1 or l2 >= r2,  
            if the two sublists are not of the same length
            or the two sublists overlap.
    """
    assert 0 <= l1 < r1 <= l2 < r2 <= len(lst), "Invalid sublist"
    assert r1-l1 == r2-l2, "Invalid sublist"

    new_lst = lst if inplace else lst.copy()
    new_lst[l1:r1], new_lst[l2:r2] = new_lst[l2:r2], new_lst[l1:r1]
    return new_lst


lst = [1, 1, 4, 5, 1, 4]
print(reverse_sublist(lst, 0, 3, False))
print(lst)
print(reverse_sublist(lst, 4, 6, True))
print(lst)
print(rotate_sublist(lst, 0, 3, 1, False))
print(lst)
print(swap_sublist(lst, 1, 2, 2, 3, True))
print(lst)
print(swap_sublist(lst, 0, 2, 4, 6, False))
print(lst)
