from typing import List, Dict, Optional
from math import log10

# Input
n: int = int(input())
docs: List[List[str]] = [input().split() for _ in range(n)]


# Helper function for bucket counter
def update_term_freq(freq: Dict[str, int],
                     terms: List[str] | Dict[str, int]) -> Dict[str, int]:
    for term in terms:
        freq[term] = freq.get(term, 0) + 1
    return freq


# Counting for frequency first
term_freq: List[Dict[str, int]] = [update_term_freq({}, doc) for doc in docs]
# Calculate log(#+1) for final TF
term_freq: List[Dict[str, float]] = [{term: log10(value+1) for term, value in freq.items()}
                                     for freq in term_freq]

# Counting for frequency first
doc_freq: Dict[str, int] = {}
for freq in term_freq:
    # For each document, every words + 1
    update_term_freq(doc_freq, freq)
# Calculate final IDF
inv_doc_freq: Dict[str, float] = {term: log10(n / value)
                                  for term, value in doc_freq.items()}

# Calculate final TF-IDF
tf_idf = [{term: tf * inv_doc_freq[term] for term, tf in freq.items()}
          for freq in term_freq]
# Select keywords
keyword = [max(val_in_doc, key=val_in_doc.get) for val_in_doc in tf_idf]

# Output
for i in range(n):
    print(f"{keyword[i]} {tf_idf[i][keyword[i]]:.4f}")
