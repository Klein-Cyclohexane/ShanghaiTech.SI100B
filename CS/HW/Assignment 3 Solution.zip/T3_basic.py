from typing import List, Dict, Optional
from math import log10

n = int(input())
docs = [input().split() for _ in range(n)]
term_freq = [{} for _ in range(n)]

for doc, freq in zip(docs, term_freq):
    for term in doc:
        # Also can try: freq[word] = freq.get(word, 0) + 1
        if term in freq:
            freq[term] += 1
        else:
            freq[term] = 1

doc_freq = {}
for freq in term_freq:
    for term, value in freq.items():
        # Calculate true TF
        freq[term] = log10(value+1)
        # Also can try: doc_freq[term] = doc_freq.get(term, 0) + 1
        if term in doc_freq:
            doc_freq[term] += 1
        else:
            doc_freq[term] = 1

inv_doc_freq = {}
for term, value in doc_freq.items():
    inv_doc_freq[term] = log10(n / value)

tf_idf = [{} for _ in range(n)]
keyword = ["" for _ in range(n)]
for i, freq in enumerate(term_freq):
    for term, value in freq.items():
        tf_idf[i][term] = value * inv_doc_freq[term]
        # From Python 3.7, dictionaries retain insertion order internally.
        if keyword[i] == "" or tf_idf[i][term] > tf_idf[i][keyword[i]]:
            keyword[i] = term

for i in range(n):
    print(f"{keyword[i]} {tf_idf[i][keyword[i]]:.4f}")
