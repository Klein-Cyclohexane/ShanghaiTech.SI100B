import math
import string
from typing import List, Dict, Tuple


# ===== Helper functions =====

def text_to_list(input_text: str) -> List[str]:
    """
    Convert the input text to a list of words. You need to remove all punctuation and convert the text to lowercase by calling the remove_punctuation function.
    Args:
        input_text: string, text to convert to a list of words
    Returns:
        list[str], list of words
    """
    return input_text.split()


def get_frequencies(input_list: List[str]) -> Dict[str, int]:
    """
    Get the frequencies of the words in the input iterable.
    Args:
        input_list: list of strings, words to get frequencies of
    Returns:
        dict[str, int], dictionary of words mapping to their frequencies
    """
    frequencies = {}
    for word in input_list:
        if word in frequencies:
            frequencies[word] += 1
        else:
            frequencies[word] = 1
    return frequencies


def tf(input_text: str) -> Dict[str, float]:
    """
    Get the TF of the words in the input text.
    Args:
        input_text: string, text to get TF of
    Returns:
        dict[str, float], dictionary of words and their TFs
    * TF is calculatd as TF(i) = (number times word *i* appears
        in the document) / (total number of words in the document)
    * Think about how we can use get_frequencies from earlier
    """
    frequencies = get_frequencies(text_to_list(input_text))
    tf_dict = {}
    for word, freq in frequencies.items():
        tf_dict[word] = math.log10(freq+1)
    return tf_dict


def idf(input_texts: List[str],) -> Dict[str, float]:
    """
    Get the IDF of the words in the input texts.
    Args:
        input_texts: list of strings, texts to get IDF of
    Returns:
        dict[str, float], dictionary of words and their IDFs
     * IDF is calculated as IDF(i) = log_10(total number of documents / number of
    documents with word *i* in it), where log_10 is log base 10 and can be called
    with math.log10()
    """
    idf_dict = {}
    for text in input_texts:
        frequencies = get_frequencies(text_to_list(text))
        for word, freq in frequencies.items():
            if word in idf_dict:
                idf_dict[word] += 1
            else:
                idf_dict[word] = 1
    for word, freq in idf_dict.items():
        idf_dict[word] = math.log10(len(input_texts) / freq)
    return idf_dict


def tfidf(tf_text: str, idf_texts: List[str]) -> List[Tuple[str, float]]:
    """
    Get the TF-IDF of the words in the input texts.
    Args:
        tf_text: string, text to get TF of
        idf_texts: list of strings, texts to get IDF of
    Returns:
        list[tuple[str, float]], list of tuples of words and their TF-IDFs
    * TF-IDF is calculated as TF-IDF(i) = TF(i) * IDF(i)
    """
    # ===== Your code here =====
    tf_dict = tf(tf_text)
    idf_dict = idf(idf_texts)
    tfidf_dict = {}
    for word, tf_value in tf_dict.items():
        if word in idf_dict:
            tfidf_dict[word] = tf_value * idf_dict[word]
        else:
            tfidf_dict[word] = tf_value * 0
    return [(word, tfidf_value) for word, tfidf_value in sorted(tfidf_dict.items(), key=lambda x: x[1], reverse=True)]


# ===== Main program (handle N-line input, exceptions, find keywords) =====
def main():
    # ===== Your code here =====
    n = int(input())
    texts = []
    for _ in range(n):
        text = input()
        texts.append(text)

    for text in texts:
        tfidf_list = tfidf(text, texts)
        print(f"{tfidf_list[0][0]} {round(tfidf_list[0][1], 4):.4f}")


if __name__ == "__main__":
    main()
